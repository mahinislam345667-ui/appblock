APK পাওয়ার দুটো উপায়:
১) Android Studio: এই ফোল্ডারটা Open করুন -> Build > Build APK(s)
২) GitHub: নতুন repo বানিয়ে এই সব ফাইল আপলোড করুন -> Actions ট্যাব -> Build APK -> Artifacts থেকে AppLocker-APK নামান
