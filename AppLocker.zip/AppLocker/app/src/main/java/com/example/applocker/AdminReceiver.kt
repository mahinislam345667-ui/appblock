package com.example.applocker

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "লক চলাকালীন অ্যাডমিন বন্ধ করা যাবে না।"
}
