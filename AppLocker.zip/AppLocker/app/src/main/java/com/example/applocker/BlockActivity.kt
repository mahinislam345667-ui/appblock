package com.example.applocker

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.widget.TextView

class BlockActivity : Activity() {
    private var timer: CountDownTimer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val tv = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER
        }
        setContentView(tv)
        val left = Prefs.remaining(this)
        timer = object : CountDownTimer(left.coerceAtLeast(0), 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                tv.text = "🔒 অ্যাপটি লক আছে\n\nবাকি: %02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
            }
            override fun onFinish() { finish() }
        }.start()
    }

    override fun onBackPressed() { /* ব্যাক চাপলে কিছু হবে না */ }
    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
