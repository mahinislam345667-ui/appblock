package com.example.applocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class BlockerService : AccessibilityService() {

    // লক চলাকালীন এগুলোও আটকানো হবে, যাতে সার্ভিস বন্ধ বা আনইনস্টল করা না যায়
    private val protectedPkgs = setOf(
        "com.android.settings",
        "com.google.android.packageinstaller",
        "com.android.packageinstaller"
    )

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Prefs.isLocked(this)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (pkg in Prefs.blocked(this) || pkg in protectedPkgs) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            startActivity(Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { Prefs.checkpoint(this@BlockerService); handler.postDelayed(this, 60_000) }
    }

    override fun onServiceConnected() { handler.post(tick) }
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onInterrupt() {}
}
