package com.example.applocker

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        if (Prefs.isLocked(this)) {
            root.addView(TextView(this).apply {
                textSize = 20f
                text = "🔒 লক চলছে। শেষ হওয়ার আগে কিছু বদলানো যাবে না।"
            })
            return
        }

        root.addView(Button(this).apply {
            text = "Accessibility সার্ভিস চালু করুন (একবার)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        root.addView(Button(this).apply {
            text = "আনইনস্টল সুরক্ষা চালু করুন (Device Admin)"
            setOnClickListener {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(context, AdminReceiver::class.java)))
            }
        })

        val minutes = EditText(this).apply { hint = "কত মিনিটের জন্য লক?"; inputType = 2 }
        root.addView(minutes, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val boxes = apps.map { app ->
            CheckBox(this).apply { text = pm.getApplicationLabel(app).toString(); tag = app.packageName }
                .also { root.addView(it) }
        }

        root.addView(Button(this).apply {
            text = "লক শুরু করুন"
            setOnClickListener {
                val sel = boxes.filter { it.isChecked }.map { it.tag as String }.toSet()
                val min = minutes.text.toString().toLongOrNull() ?: 0
                if (sel.isEmpty() || min <= 0) {
                    Toast.makeText(context, "অ্যাপ ও মিনিট দিন", Toast.LENGTH_SHORT).show(); return@setOnClickListener
                }
                Prefs.startLock(context, sel, min)
                recreate()
            }
        })
    }
}
