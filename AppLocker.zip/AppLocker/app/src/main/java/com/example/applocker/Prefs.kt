package com.example.applocker

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("locker", Context.MODE_PRIVATE)
    private fun bootCount(c: Context) = Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, -1)

    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet()) ?: emptySet()

    /** বাকি সময় (ms)। ফোনের ঘড়ি বদলালে এটা প্রভাবিত হয় না। */
    fun remaining(c: Context): Long {
        val p = sp(c)
        val anchorRem = p.getLong("anchorRem", 0L)
        if (anchorRem <= 0) return 0
        val nowEl = SystemClock.elapsedRealtime()
        // একই বুটে থাকলে elapsedRealtime দিয়ে হিসাব
        return if (p.getInt("boot", -2) == bootCount(c)) {
            (anchorRem - (nowEl - p.getLong("anchorEl", nowEl))).coerceAtLeast(0)
        } else {
            // রিস্টার্ট হয়েছে: শেষ সেভ করা বাকি সময় থেকেই নতুন করে গোনা শুরু (বন্ধ থাকার সময় ধরা হয় না)
            p.edit().putInt("boot", bootCount(c)).putLong("anchorEl", nowEl).apply()
            anchorRem
        }
    }

    fun isLocked(c: Context) = remaining(c) > 0

    /** সার্ভিস প্রতি মিনিটে এটা ডাকে, যাতে রিস্টার্টেও সঠিক বাকি সময় থাকে */
    fun checkpoint(c: Context) {
        val rem = remaining(c)
        sp(c).edit().putLong("anchorRem", rem)
            .putLong("anchorEl", SystemClock.elapsedRealtime())
            .putInt("boot", bootCount(c)).apply()
    }

    fun startLock(c: Context, pkgs: Set<String>, minutes: Long) {
        if (isLocked(c)) return
        sp(c).edit()
            .putStringSet("blocked", pkgs)
            .putLong("anchorRem", minutes * 60_000)
            .putLong("anchorEl", SystemClock.elapsedRealtime())
            .putInt("boot", bootCount(c))
            .apply()
    }
}
